<?php

/**
 * Copyright (C) 2020 Tencent Cloud.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

namespace App\User;

use App\Censor\Censor;
use App\Common\ResponseCode;
use App\Exceptions\UploadException;
use App\Models\User;
use Discuz\Contracts\Setting\SettingsRepository;
use Illuminate\Contracts\Filesystem\Factory;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Str;
use Intervention\Image\Image;

class BackgroundUploader
{
    /**
     * @var Censor
     */
    protected $censor;

    /**
     * @var Filesystem
     */
    protected $filesystem;

    /**
     * @var SettingsRepository
     */
    protected $settings;

    /**
     * @param Censor $censor
     * @param Filesystem $filesystem
     * @param SettingsRepository $settings
     */
    public function __construct(Censor $censor, Filesystem $filesystem, SettingsRepository $settings)
    {
        $this->censor = $censor;
        $this->filesystem = $filesystem;
        $this->settings = $settings;
    }

    /**
     * @param User $user
     * @param Image $image
     * @throws UploadException
     */
    public function upload(User $user, Image $image)
    {
        /*if (extension_loaded('exif')) {
            $image->orientate();
        }*/
        $oldEncodedImage = $image->encode('png')->save();

        // 检测敏感图
        $this->censor->checkImage($image->dirname .'/'. $image->basename);

        if ($this->censor->isMod) {
            \Discuz\Common\Utils::outPut(ResponseCode::NOT_ALLOW_CENSOR_IMAGE);
        }

        $backgroundPath = $this->getBackgroundPath($user);
        $uid = sprintf('%09d', $user->id);
        $dir1 = substr($uid, 0, 3);
        $dir2 = substr($uid, 3, 2);
        $dir3 = substr($uid, 5, 2);
        $oldBackGroundPath = str_replace($dir1.'/'.$dir2.'/'.$dir3.'/',$dir1.'/'.$dir2.'/'.$dir3.'/'.'original_',$backgroundPath);
        // 判断是否开启云储存
        if ($this->settings->get('qcloud_cos', 'qcloud')) {
            $user->changeBackground($backgroundPath, true);
            $backgroundPath = 'public/background/' . $backgroundPath;
            $oldBackGroundPath = 'public/background/' . $oldBackGroundPath;
        } else {
            $user->changeBackground($backgroundPath);
        }
        $this->filesystem->put($oldBackGroundPath, $oldEncodedImage);
        $encodedImage = $image->fit(1200, 800)->encode('png')->save();
        $this->filesystem->put($backgroundPath, $encodedImage);
    }

    /**
     * 删除头像
     *
     * @param User $user
     */
    public function remove(User $user)
    {
        $avatarPath = $user->getRawOriginal('background');

        $user->saved(function () use ($avatarPath) {
            $this->deleteFile($avatarPath);
        });

        $user->changeAvatar(null);
    }

    /**
     * 上传失败则删除 本地/COS 图片资源
     *
     * @param $avatarPath
     */
    public function deleteFile($avatarPath)
    {
        // 判断是否是cos地址
        if (strpos($avatarPath, '://') === false) {
            if ($this->filesystem->has($avatarPath)) {
                $this->filesystem->delete($avatarPath);
            }
        } else {
            $cosPath = 'public/background/' . Str::after($avatarPath, '://');
            // 判断是否关闭了腾讯COS
            if ($this->settings->get('qcloud_cos', 'qcloud')) {
                $this->filesystem->delete($cosPath);
            } else {
                app(Factory::class)->disk('background_cos')->delete($cosPath);
            }
        }
    }

    public function getBackgroundPath(User $user)
    {
        $uid = sprintf('%09d', $user->id);
        $dir1 = substr($uid, 0, 3);
        $dir2 = substr($uid, 3, 2);
        $dir3 = substr($uid, 5, 2);
        $str = Str::random(40);
        return $dir1.'/'.$dir2.'/'.$dir3.'/'.$str.'.png';
    }
}
